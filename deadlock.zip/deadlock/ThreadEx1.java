package com.dell.deadlock;
class Demo1 extends Thread{
	public void run() {
		for(int i=1;i<=3;i++) {
			System.out.println("running 1 task..");
		}
	}
}
class Demo2 extends Thread{
	public void run() {
		for(int i=1;i<=3;i++) {
			System.out.println("running 2 task..");
		}
	}
}
public class ThreadEx1 {
	public static void main(String[] args) {
		Demo1 d1=new Demo1();
		Demo2 d2=new Demo2();
		
		d1.start();
		d2.start();
	}
}
