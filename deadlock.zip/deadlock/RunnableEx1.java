package com.dell.deadlock;
class Superclass{
	
}
class Sub1 extends Superclass implements Runnable{
	
	public void run() {
		
			System.out.println("Running 1 task..");
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
class Sub2 extends Superclass implements Runnable{
	public void run() {
		System.out.println("Running 2 task..");
	}
}
public class RunnableEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sub1 s1=new Sub1();
		Sub2 s2=new Sub2();
		
		Thread t1=new Thread(s1);
		Thread t2=new Thread(s2);
		
		t1.start();
		t2.start();
		
	}

}
