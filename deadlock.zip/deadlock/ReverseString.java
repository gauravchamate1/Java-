package com.dell.deadlock;

import java.util.Scanner;

public class ReverseString {
	public static void rev(String a) {
		String res=" ";
		char[] b=a.toCharArray();
		for(int i=b.length-1;i>=0;i--) {
			res=res+b[i];
		}
		System.out.println("Result is :"+res);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string:");
		String c=sc.next();
		rev(c);
	}

}
