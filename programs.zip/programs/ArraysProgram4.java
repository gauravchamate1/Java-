package com.arrays.programs;

public class ArraysProgram4 {
	// Java Program to find the smallest positive missing number
		static int solution(int[] A)
		{
			int n = A.length;
			
			int N = 1000010;

			// To mark the occurrence of elements
			boolean[] present = new boolean[N];

			int maxele = Integer.MIN_VALUE;

			// Mark the occurrences
			for (int i = 0; i < n; i++) {
				if (A[i] > 0 && A[i] <= n)
					present[A[i]] = true;
				maxele = Math.max(maxele, A[i]);
			}

			// Find the first element which didn't
			// appear in the original array
			for (int i = 1; i < N; i++)
				if (!present[i])
					return i;

			// If the original array was of the
			// type {1, 2, 3} in its sorted form
			return maxele + 1;
		}

		// Driver Code
		public static void main(String[] args)
		{
			int arr[] = { 0, 10, 2, -10, -20 };
			System.out.println(solution(arr));
		}
	}



