package com.gsa.Recurrsion;

public class RecurrsionEx7 {
	public static void rep(int a) {
		if(a==20) {
			return;
		}
		if(a%2==1) {
			System.out.println(a);
		}
		a++;
		rep(a);
	}
	
	public static void main(String[] args) {
		rep(1);
	}
}
