package com.gsa.Recurrsion;

public class RecurrsionEx2 {
	public static void rep(int a) {
		if(a==3) {
			return;
		}
		System.out.println("Repeat..");
		a++;
		rep(a);
	}
	public static void main(String[] args) {
		rep(0);
	}
}
