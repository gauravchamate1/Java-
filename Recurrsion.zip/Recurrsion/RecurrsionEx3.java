package com.gsa.Recurrsion;

import java.util.Scanner;

public class RecurrsionEx3 {
	public static void rep(int a) {
		if(a==0) {
			return;
		}
		System.out.println("Repeat..");
		a--;
		rep(a);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value for a:");
		int a=sc.nextInt();
		rep(a);
		
	}
}
