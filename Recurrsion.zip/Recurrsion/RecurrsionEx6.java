package com.gsa.Recurrsion;

public class RecurrsionEx6 {
	public static void rep(int a) {
		if(a==50) {
			return;
		}
		if(a%2==0) {
			System.out.println(a);
		}
		a++;
		rep(a);
	}
	
	public static void main(String[] args) {
		rep(1);
	}
}
