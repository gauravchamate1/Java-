package com.gsa.Recurrsion;

import java.util.Scanner;

public class RecurrsionEx5 {
	public static void inc(int a) {
		if(a==11) {
			return;
		}
		System.out.println(a);
		a++;
		inc(a);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value:");
		int a=sc.nextInt();
		inc(a);
		}
}
