package com.gsa.Recurrsion;

import java.util.Scanner;

public class RecurrsionEx4 {
	public static void rep(int a) {
		if(a==3) {
			return;
		}
		System.out.println("Repeat..");
		a++;
		rep(a);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value:");
		int a=sc.nextInt();
		rep(a);
	}
}
