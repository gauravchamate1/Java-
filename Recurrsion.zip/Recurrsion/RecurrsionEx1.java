package com.gsa.Recurrsion;

public class RecurrsionEx1 {
	public static void repeat(int a) {
		if(a==0) {
			return;
		}
		System.out.println("Repet");
		a--;
		repeat(a);
	}
	public static void main(String[] args) {
		repeat(5);
	}
}
