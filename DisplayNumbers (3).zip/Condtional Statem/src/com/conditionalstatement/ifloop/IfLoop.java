package com.conditionalstatement.ifloop;

public class IfLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=10;
		
		if(number>0) {
			System.out.println("Number is positive");
		}
		else {
			System.out.println("Number is negative");
		}
	}

}
