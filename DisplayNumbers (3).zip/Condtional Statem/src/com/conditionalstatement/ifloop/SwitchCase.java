package com.conditionalstatement.ifloop;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter your age:");
		age = scanner.nextInt();
		
		switch (age) {
		case 1:
			System.out.println("you can crawl");
			break;
		case 2:
			System.out.println("you can talk");
			break;
		case 3:
			System.out.println("you can get in trouble");
			break;
		default:
			System.out.println("i dnt know how old you are");
			break;
		}
	}
}
