package com.conditionalstatement.ifloop;

import java.util.Scanner;

public class ElseIfLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner num= new Scanner(System.in);
System.out.println("Enter any integer value");


int number= num.nextInt();
if( number%2==0) {
	System.out.println("even number");
}else {
	System.out.println("odd number");
}
	}

}
