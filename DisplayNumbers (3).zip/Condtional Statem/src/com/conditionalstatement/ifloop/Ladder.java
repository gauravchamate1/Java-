package com.conditionalstatement.ifloop;

import java.util.Scanner;

public class Ladder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner kb= new Scanner(System.in);
System.out.println("Enter your 1 for sedan, 2 for SUV,3 for sports, 4 cross Breed");
int choice=kb.nextInt();

if(choice==1) {
	System.out.println("Sedan class");
	
	
}

else if(choice==2) {
	System.out.println("SUV class");
	
}
else if(choice==3) {
	System.out.println("Sports class");
	
}
else if(choice==4) {
	System.out.println("crossbreed segment");
	
	
}
else {
	System.out.println("Invalid choice");
}
}

}
