package com.conditionalstatement.ifloop;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//	int i =0;
//	while (i<5) {
//		System.out.println(i);
//		i++;
//	}
int i=1;
while(i<=100) {
	if(i%2!=0) {
	System.out.println(i);
	
}
	i++;
}
}
	}
