package com.conditionalstatement.ifloop;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int m=2;
 int n=3;
 
 int res;
 
 res = m+n;
 System.out.println(res);
 
 
	}

}
