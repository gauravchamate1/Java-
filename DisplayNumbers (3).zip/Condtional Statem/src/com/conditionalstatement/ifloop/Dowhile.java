package com.conditionalstatement.ifloop;

public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int i=0;
//		do {
//			System.out.println(i);
//			i++;
//		} while (i<5);
		int count =60;
		do {
			if(count%3==0 && count%8==0) {
				System.out.println(count);
			
			}
		count++;

		}

		while(count<=100); {
			System.out.println("this is while loop");
		}
	}
	}

