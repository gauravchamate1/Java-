package com.conditionalstatement.ifloop;

import java.util.Scanner; // Needed for the Scanner class

public class Switch {

	public static void main(String[] args) {
		char choice; // To store the user's choice

		// Create a Scanner object to read input.
		Scanner console = new Scanner(System.in);

		// Ask the user to enter y or n.
		System.out.print("Enter Y or N: ");
		choice = console.next().charAt(0);

		// Determine which character the user entered.
		switch (choice) {
		case 'Y':
		case 'y':
			System.out.println("You entered Y.");

			break;

		case 'N':
		case 'n':
			System.out.println("You entered N.");

			break;

		default:
			System.out.println("Incorrect Input!");
		}
	}
}
