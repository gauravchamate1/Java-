package com.numbers.descendingorder;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int count=1; count<=100;count++) {
	if((count%2==0)||(count%5==0)){
		System.out.println(count);
	}
}
	}

}
