package com.identifiers.operator;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a1;
int b1;
int res;

a1=50;
b1=40;
res=a1+b1;
System.out.println(res);
	}

}

