package com.identifiers.operator;

public class PerimeterOfCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double rad=2;
double perimeter;

perimeter = 2*3.14*rad;

System.out.println(perimeter);
	}

}
