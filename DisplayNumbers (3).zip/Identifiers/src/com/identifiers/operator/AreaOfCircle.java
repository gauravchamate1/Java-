package com.identifiers.operator;

public class AreaOfCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("program starts");

float rad=5.2f;
double area;


area =3.14*rad*rad;
System.out.println(area);
	}

}
