package com.dell.streams;
//Importing required classes
import java.io.*;
import java.util.*;

public class Example3 {
		// Main driver method
		public static void main(String[] args)
		{
			// Creating an empty Arraylist
			List<String> CompanyList = new ArrayList<>();

			// Adding elements to above ArrayList
			CompanyList.add("Google");
			CompanyList.add("Apple");
			CompanyList.add("Microsoft");

			// Sorting the list
			// using sorted() method and
			// printing using for-each loop
			CompanyList.stream().sorted().forEach(
				System.out::println);
		}
	}


