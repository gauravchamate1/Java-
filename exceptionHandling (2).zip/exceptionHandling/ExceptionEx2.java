package com.gsa.exceptionHandling;

public class ExceptionEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=50;
		try {
		System.out.println("Print "+i/0);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Hai Gsa..");
	}

}