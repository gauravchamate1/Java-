package com.gsa.exceptionHandling;

public class ExceptionEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=50;
		System.out.println("Print "+i/0);
		/*try {
		System.out.println("Print "+i/0);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		System.out.println("Print...");
	}

}
