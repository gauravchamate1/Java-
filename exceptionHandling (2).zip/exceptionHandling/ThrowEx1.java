package com.gsa.exceptionHandling;

public class ThrowEx1 {
	
	public static void validate(int age) {
		if(age<18) {
			ArithmeticException ae=new ArithmeticException("Not Valid..");
			throw ae;
		}
		else {
			System.out.println("Welcome to vote..");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		validate(20);
		System.out.println("Rest Code..");
	}

}
