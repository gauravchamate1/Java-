package com.gsa.exceptionHandling;

public class MultiCatchEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=50;
		int[] a= {2,3,4,5};
		
		try {
			System.out.println("Print "+i/0);
			System.out.println("Array "+a[6]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Task2 Exception Handled..");
			e.printStackTrace();
		}
		catch(ArithmeticException e) {
			System.out.println("Task1 Exception Handled..");
			e.printStackTrace();
		}
		System.out.println("Rest code..");
		
	}

}
