package com.gsa.exceptionHandling;

public class FinalizeEx1{  
public void finalize(){
	System.out.println("finalize called");
	}  
public static void main(String[] args){  
	FinalizeEx1 f1=new FinalizeEx1();  
	FinalizeEx1 f2=new FinalizeEx1();  
f1=null;  
f2=null;  
System.gc();  
}
}  