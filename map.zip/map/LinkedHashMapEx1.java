package com.gsa.map;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LinkedHashMapEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap<Integer, String> l1=new LinkedHashMap<Integer,String>();
		l1.put(1, "Gsa");
		l1.put(1, "Gsa");
		l1.put(2, "Gmk");
		l1.put(3, "Gmk");
		l1.put(null, "gs");
		
		
		for (Entry<Integer, String> str : l1.entrySet()) {
			System.out.println(str.getValue()+" "+str.getKey());
		}
	}

}
