package com.gsa.map;

import java.util.HashMap;
import java.util.Map;

public class HashMapEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> h1=new HashMap<Integer,String>();
		h1.put(1, "Gsa");
		h1.put(2, "Gsa");
		h1.put(3, "Gmk");
		h1.put(null, "Gk");
		h1.put(4,null);
		/*System.out.println(h1.get(1));
		System.out.println(h1.get(2));
		System.out.println(h1.get(3));
		System.out.println(h1.get(null));
		System.out.println(h1.get(4));*/
		
		for (HashMap.Entry<Integer, String> m2 : h1.entrySet()) {
			System.out.println(m2.getKey()+" "+m2.getValue());
		}
	}

}
