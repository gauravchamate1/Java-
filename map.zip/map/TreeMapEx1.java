package com.gsa.map;

import java.util.Map.Entry;
import java.util.TreeMap;

public class TreeMapEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String> t1=new TreeMap<Integer,String>();
		t1.put(1, "Gsa");
		t1.put(1, "Gmk");
		t1.put(2, "Gsa");
		//t1.put(null, "Good");
		
		for (Entry<Integer, String> str : t1.entrySet()) {
			System.out.println(str.getKey()+" "+str.getValue());
		}
	}

}
